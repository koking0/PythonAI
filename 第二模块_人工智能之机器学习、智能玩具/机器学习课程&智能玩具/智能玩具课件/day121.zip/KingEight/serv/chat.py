from flask import Blueprint, request, jsonify, send_file
from settings import MONGO_DB, RET
from bson import ObjectId

ch = Blueprint("ch", __name__)


@ch.route("/open_chat", methods=["POST"])
def open_chat():
    user_id = request.form.get("user_id")
    friend_id = request.form.get("friend_id")
    print(user_id,friend_id)
    chat_window = MONGO_DB.chat.find_one({"user_list": {"$all": [friend_id, user_id]}})
    print(chat_window)
    chat_window["_id"] = str(chat_window["_id"])

    RET["code"] = 0
    RET["msg"] = "聊天窗口"
    RET["data"] = chat_window


    return jsonify(RET)
