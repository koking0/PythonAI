from settings import SPEECH

def text2audio(text):
    res = SPEECH.synthesis(text,options={
        "vol":8,
        "pit":8,
        "spd":5,
        "per":4
    })

    with open("Nolic.mp3","wb") as f:
        f.write(res)


text2audio("当前玩具未被授权")