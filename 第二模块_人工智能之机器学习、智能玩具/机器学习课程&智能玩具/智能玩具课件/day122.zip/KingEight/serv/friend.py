from flask import Blueprint, request, jsonify, send_file
from settings import MONGO_DB, RET
from bson import ObjectId

fri = Blueprint("fri", __name__)

@fri.route("/friend_list",methods=["POST"])
def friend_list():
    user_id = request.form.get("user_id")
    res = MONGO_DB.users.find_one({"_id":ObjectId(user_id)})
    friend_list = res.get("friend_list")

    RET["code"] = 0
    RET["msg"] = "获取好友列表"
    RET["data"] = friend_list

    return jsonify(RET)